package com.example.online_ticket_booking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
