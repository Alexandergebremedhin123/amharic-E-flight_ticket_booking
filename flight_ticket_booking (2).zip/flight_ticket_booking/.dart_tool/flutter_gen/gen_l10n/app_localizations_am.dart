import 'app_localizations.dart';

/// The translations for Amharic (`am`).
class AppLocalizationsAm extends AppLocalizations {
  AppLocalizationsAm([String locale = 'am']) : super(locale);

  @override
  String get language => 'አማርኛ';

  @override
  String get helloWorld => 'Hello World!';

  @override
  String get multilanguage => 'Multi Language';

  @override
  String hello(String username) {
    return 'Hello $username';
  }
}
