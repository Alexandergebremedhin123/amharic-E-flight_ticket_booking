List<Map<String,dynamic>> hotelList=[
  {
    'image':'one.png',
    'place':'Central Hotel',
    'destination':'Jimma',
    'price':'400 birr'
  },
  {
    'image':'two.jfif',
    'place':'Boni International Hotel',
    'destination':'Jimma',
    'price':'500 birr'
  },
  {
    'image':'three.jfif',
    'place':'Awettu Grand Hotel',
    'destination':'Jimma',
    'price':'750 birr'
  },

];
List<Map<String,dynamic>> ticketList=[
  {
    'from':{
      'code':"JIMMA",
      'name':"ጅማ"
    },
    'to':{
      'code':"ADDIS ABABA",
      'name':"አዲስ አበባ"
    },
    'flying_time':'7H 30M',
      'date':"ግንቦት 1",
      'departure_time':"05:00 AM",
      "number":23
    },
  {
    'from':{
      'code':"METTU",
      'name':"መቱ"
     },
    'to':{
      'code':"ADDIS ABABA",
      'name':"አዲስ አበባ"
    },
    'flying_time':'6H 30M',
    'date':"ግንቦት 3",
    'departure_time':"09:00 AM",
    'number':45
  },
];