
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:online_ticket_booking/screens/hotel_screen.dart';
import 'package:online_ticket_booking/screens/ticket_view.dart';
import 'package:online_ticket_booking/utils/app_info_list.dart';
import 'package:online_ticket_booking/utils/app_styles.dart';
import 'package:online_ticket_booking/widgets/double_text_widget.dart';
import 'package:gap/gap.dart';
import 'package:fluentui_icons/fluentui_icons.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:Styles.bgColor,
      body:ListView(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child:Column(
              children: [
                SizedBox(height: 40), //const Gap(40),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                  Column(
                    crossAxisAlignment:CrossAxisAlignment.start,
                    children:  [
                      Text(
                          "Ticket Booking",
                        style: Styles.headLineStyle1,
                      ),
                   const Gap(5),
                      Text(
                        "ኦንላይን የበረራ ቲኬት መሸጫ",
                        style: Styles.headLineStyle3,
                      ),
                    ],
                  ),
                    /*
                    Image.asset("assets/images/img_1.png")
                     */
                    Container(
                      height:50,
                      width:50,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          /*image: const DecorationImage(
                                fit:BoxFit.fitHeight,
                              image: AssetImage(
                                "assets/images/img_1.png"
                            )
                          )*/
                        ),
                    )
                  ],

                ),
               const Gap(25),
                Container(
                  decoration:BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: const Color(0xFFF4F6FD)
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 12),
                  child: Row(
                    children: [
                      const Icon(FluentSystemIcons.ic_fluent_search_regular,color: Color(0xFFBFC205),),
                   Text(
                     "ፈልግ ",
                     style: Styles.headLineStyle4,
                   )
                    ],
                  ),
                ),
                const Gap(40),
                AppDoubleTextWidget(bigText: "መጪ በረራዎች ", smallText: "ሁሉን እይ ")
              ],
            ),
          ),
          SizedBox(height: 15,),
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.only(left:20),
        child: Row(
          children: ticketList.map((singleTicket) => TicketView(ticket: singleTicket)).toList(),
        ),
      ),
          SizedBox(height: 5,),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child:  AppDoubleTextWidget(bigText: "Hotels", smallText: "View all")
          ),
          SizedBox(height: 5,),
          SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.only(left:20),
              child: Row(
                children: hotelList.map((singleHotel) => HotelScreen(hotel:singleHotel)).toList(),
              )),
        ],
      ),
    );
  }
}

