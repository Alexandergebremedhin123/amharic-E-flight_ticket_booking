import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:online_ticket_booking/utils/app_layout.dart';
import 'package:online_ticket_booking/utils/app_styles.dart';
import 'package:online_ticket_booking/widgets/icon_text_widget.dart';
import 'package:online_ticket_booking/widgets/ticket_tabs.dart';

import '../widgets/double_text_widget.dart';

class SearchScreen extends StatelessWidget {
  const SearchScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final size=AppLayout.getSize(context);
    return Scaffold(
      backgroundColor: Styles.bgColor,
      body: ListView(
        padding: EdgeInsets.symmetric(horizontal:AppLayout.getWidth(20),vertical:AppLayout.getHeight(20)),//AppLayout.getWidth(20)//AppLayout.getHeight(20)
        children: [
          SizedBox(height: 40,),
          Text("እርስዎ፣\n ምን ይፈልጋሉ? ",style: Styles.headLineStyle1.copyWith(fontSize: 35)),
          SizedBox(height: 20,),//AppLayout.getHeigth(40),
        AppTicketTabs(firstTab: "የበረራ ቲኬቶች ",secondTab: "ሆቴሎች ",),
          SizedBox(height: 25,),
          AppIconText(icon: Icons.flight_takeoff_rounded, text:"መለያ "),
          SizedBox(height: 20,),
          AppIconText(icon: Icons.flight_land_rounded, text:"መድረሻ "),
          SizedBox(height: 25,),
      Container(
        padding: EdgeInsets.symmetric(vertical:AppLayout.getWidth(18),horizontal: AppLayout.getHeight(15)),
        decoration: BoxDecoration(
          color: Color(0xD91130CE),
          borderRadius: BorderRadius.circular(10),
        ),
        child:Center(
                child: Text(
                  "ቲኬቱን አግኝ",
                  style: Styles.textStyle.copyWith(color: Colors.white),
                )
            )

      ),

          SizedBox(height: 40,),
          AppDoubleTextWidget(bigText: "መጪ በረራዎች", smallText: "ሁሉን እይ"),
          SizedBox(height: 15,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
         children: [
           Container(
             height: 425,
             width: size.width*0.42,
             padding: EdgeInsets.symmetric(horizontal: 15,vertical: 15),
             decoration: BoxDecoration(
               color: Colors.white,
               borderRadius: BorderRadius.circular(20),
               boxShadow: [
                 BoxShadow(
                   color: Colors.grey.shade200,
                   blurRadius: 1,
                   spreadRadius: 1
                 )
               ]
             ),
             child: Column(
               children: [
                 Container(
                   height: 190,
                   decoration: BoxDecoration(
                     borderRadius: BorderRadius.circular(12),
                     image: DecorationImage(
                       fit: BoxFit.cover,
                       image: AssetImage(
                       "assets/images/two.jfif"
                       )
                     )
                   ),

                 ),
                 SizedBox(height: 12,),
                 Text(
                   "20% ቅናሽ ከበፊቱ በረራ ላይ እርስዎ አይርሱ ",
                 style: Styles.headLineStyle2,
                 )
               ],
             ),
           ),
           Column(
             children: [
             Stack(
               children: [
                 Container(
                   width:size.width*0.44,
                   height: 200,
                   decoration: BoxDecoration(
                     color: Color(0xFF3AB8B8),
                     borderRadius: BorderRadius.circular(18),
                   ),
                   padding: EdgeInsets.symmetric(vertical:15,horizontal: 15),
                   child:Column(
                     crossAxisAlignment: CrossAxisAlignment.start,
                     children: [
                       Text("ቅናሽ\n ለ ሰርቬ",style: Styles.headLineStyle2.copyWith(fontWeight: FontWeight.bold,color: Colors.white),),
                       SizedBox(height: 10,),
                       Text("ሰርቬዎን ይዉሰዱ ቅናሽ ያግኙ",style: Styles.headLineStyle2.copyWith(fontWeight: FontWeight.w500,color: Colors.white,fontSize: 18),),
                     ],
                   ),
                 ),
                 Positioned(
                   right: -45,
                     top: -40,
                     child: Container(
                   padding: EdgeInsets.all(30),
                   decoration: BoxDecoration(
                       shape: BoxShape.circle,
                       border: Border.all(width: 18,color: Color(0xFF189999)),
                       color: Colors.transparent
                   ),
                 ))
               ],
             ),
               SizedBox(height: 15,),
               Container(
                 width: size.width*0.44,
                 height: 210,
                   padding: EdgeInsets.symmetric(vertical:15,horizontal:15),
                 decoration: BoxDecoration(
                    borderRadius:BorderRadius.circular(18),
                   color: const Color(0xFFEC6545)
                 ),
                 child: Column(
                   children: [
                     Text("ፍቅር ያግኙ",style: Styles.headLineStyle2.copyWith(color: Colors.white,fontWeight: FontWeight.bold,),textAlign: TextAlign.center,),
                     SizedBox(height: 5,),
                     RichText(
                       text: const TextSpan(
                         children: [
                           TextSpan(
                         text: '😍',//add the emoji love
                         style: TextStyle(fontSize: 32)
                           ),
                           TextSpan(
                               text: '🥰',//add the2 kiss emoji
                               style: TextStyle(fontSize: 42)
                           ),
                           TextSpan(
                               text: '😘',//add the1 kiss emoji
                               style: TextStyle(fontSize: 32)
                           ),
                         ],
                       ),
                     )
                   ],
                 ),
               )
             ],
           )
         ],
       )
        ],
      ),
    );
  }
}
